import React, { useContext, useState, useEffect, useRef } from 'react';
import { Table, Input, Button, Popconfirm, Form, Radio } from 'antd';
import './App.css';
import { IntlProvider, FormattedMessage } from "react-intl";
const messages = {
  en: {
    name: "Name",
    Location: "Location",
    address: "Office",
    phone:'Phone',
    officePhone:'Office',
    cellPhone:'cell',
    add:'Add',
    delete:'Delete',
    update:'Update',
  },
  cn: {
    name: "姓名",
    Location: "驻地",
    address: "办公地址",
    phone:'联系方式',
    officePhone:'办公电话',
    cellPhone:'手机',
    add:'增加',
    delete:'删除',
    update:'更新',
  },
};
const EditableContext = React.createContext();

const EditableRow = ({ index, ...props }) => {
  const [form] = Form.useForm();
  return (
    <Form form={form} component={false}>
      <EditableContext.Provider value={form}>
        <tr {...props} />
      </EditableContext.Provider>
    </Form>
  );
};
const EditableCell = ({
  title,
  editable,
  children,
  dataIndex,
  record,
  handleSave,
  ...restProps
}) => {
  const [editing, setEditing] = useState(false);
  const inputRef = useRef();
  const form = useContext(EditableContext);
  useEffect(() => {
    if (editing) {
      inputRef.current.focus();
    }
  }, [editing]);

  const toggleEdit = () => {
    setEditing(!editing);
    form.setFieldsValue({
      [dataIndex]: record[dataIndex],
    });
  };

  const save = async e => {
    try {
      const values = await form.validateFields();
      toggleEdit();
      handleSave({ ...record, ...values });
    } catch (errInfo) {
      console.log('Save failed:', errInfo);
    }
  };

  let childNode = children;

  if (editable) {
    childNode = editing ? (
      <Form.Item
        style={{
          margin: 0,
        }}
        name={dataIndex}
        rules={[
          {
            required: true,
            message: `${title} is required.`,
          },
        ]}
      >
        <Input ref={inputRef} onPressEnter={save} onBlur={save} />
      </Form.Item>
    ) : (
      <div
        className="editable-cell-value-wrap"
        style={{
          paddingRight: 24,
        }}
        onClick={toggleEdit}
      >
        {children}
      </div>
    );
  }

  return <td {...restProps}>{childNode}</td>;
};

class EditableTable extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: 'id',
        dataIndex: 'id',
        width: '10%',
      },
      {
        title: <FormattedMessage id="name"  />,
        dataIndex: 'name',
        width: '10%',
        filterMultiple: false,
        editable: true,
        onFilter: (value, record) => record.name.indexOf(value) === 0,
        sorter: (a, b) => a.name.length - b.name.length,
        sortDirections: ['descend', 'ascend'],
      },
      {
        title: <FormattedMessage id="Location"  />,
        dataIndex: 'location',
        filterMultiple: false,
        editable: true,
        onFilter: (value, record) => record.location.indexOf(value) === 0,
        sorter: (a, b) => a.location.length - b.location.length,
        sortDirections: ['descend', 'ascend'],
      },
      {
        title: <FormattedMessage id="address"  />,
        dataIndex: 'address',
        filterMultiple: false,
        editable: true,
        onFilter: (value, record) => record.address.indexOf(value) === 0,
        sorter: (a, b) => a.address.length - b.address.length,
        sortDirections: ['descend', 'ascend'],
      },
      {
        title: <FormattedMessage id="phone"  />,
        dataIndex: 'phone',
        editable: true,
        children: [
          {
            title: <FormattedMessage id="officePhone"  />,
            dataIndex: 'office',
            editable: true,
          },
          {
            title: <FormattedMessage id="cellPhone"  />,
            dataIndex: 'cell',
            editable: true,
          },
        ]
      }
    ];
    this.state = {
      lang: "en",
      selectedRowKeys: [],
      dataSource: [
        {
          key: '0',
          id:501,
          name: 'Khali Zhang',
          location:'Shanghai',
          address:'beidi rood',
          office:'x55778',
          cell:'650-353-1239',
        },
        {
          key: '1',
          id:502,
          name: 'Khali Zhang1',
          location:'ShangHai China',
          address: 'siping road',
          office:'x55799',
          cell:'650-353-1839',
        },
      ],
      count: 2,
    };
  }

  handleAdd = () => {
    const { count, dataSource } = this.state;
    const newData = {
      key: count,
      id: '',
      name: 'please input name',
      location: 'please input locations',
      address: 'please input office address',
      office:'please input office number',
      cell:'please input cell phone number',
    };
    this.setState({
      dataSource: [...dataSource, newData],
      count: count + 1,
    });
  };
  changeLang = event => {
    console.log("selected val is ", event.target.value);
    let newlang = event.target.value;
    this.setState({lang: newlang });
    console.log("state value is", newlang);
    this.setState({lang:newlang});
  };
  handleSave = row => {
    const newData = [...this.state.dataSource];
    const index = newData.findIndex(item => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, { ...item, ...row });
    this.setState({
      dataSource: newData,
    });
  };
  handleUpdate = () =>{
    let updateRows = [...this.state.selectedRowKeys];
    alert("Are you sure to update the selected rows?"+updateRows);
    this.setState({
      selectedRowKeys:[],
    });
  }
  handleDelete = () => {
    let deletedRows = [...this.state.selectedRowKeys];
    const newData = [...this.state.dataSource].filter(item => !deletedRows.includes(item.key));
    this.setState({
      dataSource: newData,
      selectedRowKeys:[],
    });     
  }
  onSelectChange = selectedRowKeys => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    this.setState({ selectedRowKeys });
  };

  render() {
    const { dataSource,selectedRowKeys,t, i18n,lang  } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
    };
    const components = {
      body: {
        row: EditableRow,
        cell: EditableCell,
      },
    };
    const mapColumns = col => {
      if (!col.editable) {
        return col;
      }
      const newCol = {
        ...col,
        onCell: record => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleSave
        })
      };
      if (col.children) {
        newCol.children = col.children.map(mapColumns);
      }
      return newCol;
    };

    const columns = this.columns.map(mapColumns);
    return (
      <div>
        <IntlProvider locale={lang} messages={messages[lang]}>
        <Table
          components={components}
          rowClassName={() => 'editable-row'}
          bordered
          dataSource={dataSource}
          columns={columns}
          rowSelection={rowSelection}
        />
        <div className="button-wrap">
            <Button
              disabled={selectedRowKeys.length === 0}
              onClick={this.handleDelete}
              type="primary"
              width="100"
              className="button-left"
              danger
            >
              <FormattedMessage id="delete"  />
            </Button>
          <div className ="right-button-wrap">
            <Button
              onClick={this.handleUpdate}
              type="primary"
              width="100"
              className="right-button"
              disabled={selectedRowKeys.length === 0}
            >
              <FormattedMessage id="update"  />
            </Button>
            <Button
              onClick={this.handleAdd}
              type="primary"
              width="100"
              className="right-button"
            >
              <FormattedMessage id="add"  />
            </Button>
          </div>
        </div>
        <Radio.Group onChange={this.changeLang} value={this.state.lang}>
        <Radio value={'en'}>English</Radio>
        <Radio value={'cn'}>中文</Radio>
        </Radio.Group>
        </IntlProvider>
      </div>  
    );
  }
}

function App() {
  return (
    <div className="App">
      <EditableTable  />
  </div>
  );
}

export default App;
